<template>
  <div class="flex flex-wrap justify-center gap-10 mt-10 px-5 md:px-12">
    <!-- CARD 1 -->
    <div class="w-[240px] md:w-[300px] sm:max-w-[330px] bg-white/10 backdrop-blur-sm p-6 rounded-2xl text-center transition-transform duration-300 hover:-translate-y-1">
      <img src="@/assets/image/google.png" alt="Google Cloud" class="w-[120px] h-[120px] md:w-[200px] md:h-[190px] rounded-full bg-white p-4 object-contain mx-auto mb-4" />
      <h2 class="text-white mb-2">Google Cloud</h2>
      <a href="https://cloud.google.com" target="_blank" class="inline-block mt-4 px-6 py-2 bg-[#2a2a2a] text-white rounded-full hover:opacity-80 transition-opacity duration-200">
        Read More →
      </a>
    </div>

    <!-- CARD 2 -->
    <div class="w-[240px] md:w-[300px] sm:max-w-[330px] bg-white/10 backdrop-blur-sm p-6 rounded-2xl text-center transition-transform duration-300 hover:-translate-y-1">
      <img src="@/assets/image/cisco.png" alt="Cisco Academy" class="w-[120px] h-[120px] md:w-[200px] md:h-[190px] rounded-full bg-white p-4 object-contain mx-auto mb-4" />
      <h2 class="text-white mb-2">Cisco Academy</h2>
      <a href="https://www.netacad.com/" target="_blank" class="inline-block mt-4 px-6 py-2 bg-[#2a2a2a] text-white rounded-full hover:opacity-80 transition-opacity duration-200">
        Read More →
      </a>
    </div>

    <!-- CARD 3 -->
    <div class="w-[240px] md:w-[300px] sm:max-w-[330px] bg-white/10 backdrop-blur-sm p-6 rounded-2xl text-center transition-transform duration-300 hover:-translate-y-1">
      <img src="@/assets/image/dicoding.png" alt="Dicoding Indonesia" class="w-[120px] h-[120px] md:w-[200px] md:h-[190px] rounded-full bg-white p-4 object-contain mx-auto mb-4" />
      <h2 class="text-white mb-2">Dicoding Indonesia</h2>
      <a href="https://www.dicoding.com/" target="_blank" class="inline-block mt-4 px-6 py-2 bg-[#2a2a2a] text-white rounded-full hover:opacity-80 transition-opacity duration-200">
        Read More →
      </a>
    </div>
  </div>
</template>
