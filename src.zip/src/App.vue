
<template>
  <div class="app-container">
    <router-view />
  </div>
</template>
