  <template>
    <div>
      <Navbar />

      <div class="min-h-screen bg-gradient-to-br from-green-50 to-white pt-28 pb-32">
        <div class="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 px-6">

          
          <div class="mt-6">
            <h1 class="text-5xl font-extrabold mb-6">{{ course.title }}</h1>
            <p class="text-gray-700 text-lg leading-relaxed mb-6 text-justify">
  {{ course.longDesc }}
</p>


            <div class="flex items-center gap-3 mt-6">
              <img src="@/assets/image/rtech.png" class="w-25 h-10 object-contain" />
              <div class="flex flex-col justify-center mt-2">
                <p class="text-gray-800 font-semibold text-lg leading-tight">
                  Creator Rtech Academy dalam {{ course.category }}
                </p>
              </div>
            </div>

            <div class="mt-8 flex items-center gap-3 text-lg">
              ⭐ <span class="font-bold">{{ course.rating }}</span>
              <span class="text-gray-600">{{ course.students }} student</span>
            </div>
          </div>

      
          <div class="flex justify-center lg:justify-start ">
            <CardCourseInside
    :type="course.status"
    :banner="course.image"
    :students="course.students"
    :level="course.level"
    :category="course.category"
    :estimate="course.estimate"
    :access="course.access"
    :courseId="course.id"
    :courseTitle="course.title"
    :fullName="userName"
  />
          </div>

        </div>
      </div>

      <Footer />
    </div>
  </template>

  <script>
  import Navbar from "@/components/Navbar.vue";
  import Footer from "@/components/Footer.vue";
  import CardCourseInside from "@/components/CardCourseInside.vue";

  export default {
    name: "InsideCourse",
    components: { Navbar, Footer, CardCourseInside },

    data() {
      return {
        course: {},
        userName: "User Tidak Dikenal"
      };
    },

    created() {
      const id = Number(this.$route.params.id);

      const allCourses = [
        {
          id: 1,
          title: "Linux System Administration",
          longDesc:"Dalam kursus ini, Anda akan mempelajari cara kerja mendalam dari sistem Linux berbasis Ubuntu, mulai dari manajemen dasar hingga konfigurasi tingkat lanjut. Dapatkan pemahaman yang kuat tentang semua alat yang diperlukan untuk mengelola dan membangun infrastruktur Linux yang siap produksi secara efisien.",
          rating: "4.0",
          students: 39,
          status: "open",
          image: new URL("@/assets/image/banner.jpg", import.meta.url).href,
          level: "Beginner",
          category: "SysAdmin",
          estimate: "3 hari",
          access: "1 Tahun"
        },
        {
          id: 2,
          title: "Cyber Security Fundamentals",
          longDesc:"Dalam kursus ini, Anda akan mempelajari prinsip-prinsip inti dari keamanan siber modern, mulai dari memahami ancaman digital hingga menerapkan strategi pertahanan yang efektif. Bangun keterampilan dasar yang kuat dalam mengamankan sistem, jaringan, dan data, mempersiapkan Anda untuk menghadapi tantangan keamanan dunia nyata dengan percaya diri.",          
          rating: "4.8",
          students: 120,
          status: "open",
          image: new URL("@/assets/image/Banner2.jpg", import.meta.url).href,
          level: "Beginner",
          category: "Cyber Security",
          estimate: "1 minggu",
          access: "1 Tahun"
        }
      ];

      this.course = allCourses.find(c => c.id === id);

    
      this.userName = localStorage.getItem("fullName") || "User Tidak Dikenal";

      // cek status course
    const completed = JSON.parse(localStorage.getItem("completedCourses") || "[]");
  const inProgress = JSON.parse(localStorage.getItem("inProgressCourses") || "[]");

  if (completed.includes(id)) {
    this.course.status = "done";      
  } else if (inProgress.includes(id)) {
    this.course.status = "wait";       
  } else {
    this.course.status = "open";       
  }

    }
  };
  </script>
