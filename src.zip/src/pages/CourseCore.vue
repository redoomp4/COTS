<template>
  <div class="min-h-screen flex flex-col bg-white mt-16 px-4 md:px-8">

    <div class="flex-1 p-6">
      <Navbar />

      <div class="max-w-4xl mx-auto mt-6">
       <a :href="`/Course/${course.id}`" class="relative text-md text-green-600 font-medium group">
  Exit Course ➝
  <span class="absolute left-0 -bottom-0.5 w-0 h-[2px] bg-green-600 transition-all duration-300 group-hover:w-full"></span>
</a>
        
        <h1 class="text-4xl font-bold mb-6 mt-5">{{ course.title }}</h1>
        <div class="text-gray-700 leading-relaxed mb-10">
          <p class="whitespace-pre-line text-lg text-justify">
            {{ course.content }}
          </p>
        </div>
        <button
          class="bg-green-600 text-white py-2 px-6 rounded-lg hover:bg-green-700"
          @click="finishCourse"
        >
          Selesai Belajar
        </button>

      </div>

      <Footer />
    </div>

  </div>
</template>

<script>
import Navbar from "@/components/Navbar.vue";
import Footer from "@/components/Footer.vue";

export default {
  name: "CourseCore",
  components: { Navbar, Footer },

  data() {
    return {
      course: {},
    };
  },

  created() {
    const id = Number(this.$route.params.id);

    const allCourses = [
      {
        id: 1,
        title: "Introduction to Linux System Administration",
          content: `Administrasi Sistem Linux merujuk pada proses mengelola dan memelihara sistem operasi Linux, yang banyak digunakan pada server, platform cloud, dan lingkungan enterprise. Seorang administrator sistem Linux bertanggung jawab untuk memastikan bahwa sistem berjalan secara efisien, aman, dan tanpa gangguan. Peran ini mencakup konfigurasi sistem, manajemen pengguna, pemantauan performa, serta pemeliharaan layanan jaringan.

Linux dikenal karena stabilitas, skalabilitas, dan sifat open-source-nya, sehingga menjadi pilihan populer untuk infrastruktur teknologi modern. Banyak organisasi besar, pusat data, dan penyedia layanan cloud mengandalkan Linux untuk menjalankan aplikasi penting dan operasi bisnis. Oleh karena itu, mempelajari administrasi sistem Linux merupakan keahlian penting bagi siapa pun yang ingin berkarier di bidang IT, DevOps, keamanan siber, atau cloud engineering.

Mempelajari administrasi sistem Linux memberikan pengetahuan dasar tentang arsitektur sistem, sistem file, permission, dan jaringan. Materi ini juga memperkenalkan keterampilan praktis seperti menginstal perangkat lunak, mengotomasi tugas menggunakan shell script, mengelola layanan, serta memperkuat keamanan sistem. Dengan kemampuan Linux yang kuat, administrator dapat menjaga kesehatan server, mengurangi downtime, dan mendukung kelancaran operasi bisnis.`
      },
      {
        id: 2,
        title: "Cyber Security Fundamentals",
        content: `Keamanan siber (Cybersecurity) adalah praktik untuk melindungi sistem komputer, jaringan, dan data dari serangan berbahaya, akses tidak sah, dan ancaman digital. Seiring perkembangan teknologi, serangan siber menjadi semakin canggih, sehingga keamanan siber menjadi disiplin penting baik di lingkungan pribadi maupun profesional. Bidang ini berfokus pada perlindungan kerahasiaan (confidentiality), integritas (integrity), dan ketersediaan (availability)—tiga prinsip utama yang dikenal sebagai CIA Triad. Memahami prinsip-prinsip ini membantu individu dan organisasi membangun infrastruktur digital yang aman dan mampu menghadapi ancaman siber modern.

Keamanan siber mencakup berbagai topik seperti identifikasi ancaman, penilaian kerentanan, konfigurasi jaringan yang aman, enkripsi, autentikasi, dan respons insiden. Profesional keamanan harus memahami berbagai teknik serangan seperti phishing, malware, ransomware, rekayasa sosial, dan intrusi jaringan. Mereka juga perlu mengenal teknologi pertahanan seperti firewall, sistem deteksi intrusi, kontrol akses, dan enkripsi data. Penguasaan konsep-konsep ini memastikan bahwa aset digital terlindungi dengan baik dan potensi pelanggaran dapat dideteksi serta ditangani dengan cepat.

Mempelajari keamanan siber sangat penting di dunia digital saat ini, di mana perusahaan, pemerintah, dan individu sangat bergantung pada teknologi. Dengan meningkatnya kekhawatiran tentang privasi, kebocoran data, dan kejahatan siber, permintaan terhadap profesional keamanan siber terus bertambah. Mempelajari dasar-dasarnya tidak hanya mempersiapkan siswa untuk berkarier di bidang keamanan IT, peretasan etis (ethical hacking), dan forensik digital, tetapi juga membantu mereka mengembangkan pola pikir berorientasi keamanan yang sangat penting untuk melindungi sistem dan informasi penting dalam lingkungan apa pun.`
      }
    ];
    this.course = allCourses.find(c => c.id === id);
  },

  methods: {
  finishCourse() {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) {
      alert("Silakan login dulu");
      this.$router.push("/login");
      return;
    }

    const username = user.username;
    const inProgressKey = `inProgressCourses_${username}`;
    const completedKey = `completedCourses_${username}`;

    // hapus dari inProgress
    let inProgress = JSON.parse(localStorage.getItem(inProgressKey) || "[]");
    inProgress = inProgress.filter(x => x !== this.course.id);
    localStorage.setItem(inProgressKey, JSON.stringify(inProgress));

    // tambahkan ke completed
    let completed = JSON.parse(localStorage.getItem(completedKey) || "[]");
    if (!completed.includes(this.course.id)) completed.push(this.course.id);
    localStorage.setItem(completedKey, JSON.stringify(completed));

    // kembali ke halaman Course
    this.$router.push(`/Course/${this.course.id}`);
  }
}

};
</script>

